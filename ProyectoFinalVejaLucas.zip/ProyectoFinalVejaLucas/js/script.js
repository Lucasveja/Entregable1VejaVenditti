// Array de usuarios registrados por defecto
const usuariosBase = [
  { documento: "12345678", usuario: "admin", contrasena: "1234", saldo: 5000, saldoUSD: 2000, cuentas: { ahorro: "5526869", corriente: "877489", usd: "7748788" }, tarjetas: { visa: 10000, mastercard: 8000 }, movimientos: [] },
  { documento: "87654321", usuario: "lucas", contrasena: "abcd", saldo: 3000, saldoUSD: 1500, cuentas: { ahorro: "9856231", corriente: "654123", usd: "2354871" }, tarjetas: { visa: 5000, mastercard: 6000 }, movimientos: [] },
  { documento: "11223344", usuario: "carlos", contrasena: "5678", saldo: 4000, saldoUSD: 2500, cuentas: { ahorro: "4567890", corriente: "123987", usd: "7896543" }, tarjetas: { visa: 12000, mastercard: 9000 }, movimientos: [] },
];

// Cargar usuarios desde localStorage o inicializar con valores por defecto
let usuarios = JSON.parse(localStorage.getItem("usuarios")) || usuariosBase;

// Guardar usuarios actualizados en localStorage si no existen
localStorage.setItem("usuarios", JSON.stringify(usuarios));

// Referencias al DOM
const loginForm = document.getElementById("login-form");
const documentoInput = document.getElementById("documento");
const usernameInput = document.getElementById("username");
const passwordInput = document.getElementById("password");
const messageDiv = document.getElementById("message");
const dashboard = document.getElementById("dashboard");
const navBar = document.querySelector("nav");
const saldoPesos = document.getElementById("saldo-pesos");
const saldoDolares = document.getElementById("saldo-dolares");
const cuentaAhorro = document.getElementById("cuenta-ahorros");
const cuentaCorriente = document.getElementById("cuenta-corriente");
const cuentaUSD = document.getElementById("cuenta-usd");
const limiteVisa = document.getElementById("limite-visa");
const limiteMastercard = document.getElementById("limite-mastercard");
const logoutButton = document.getElementById("logout-button");

let usuarioActivo = null;

// Manejo del inicio de sesion
loginForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const documento = documentoInput.value;
  const username = usernameInput.value;
  const password = passwordInput.value;
  
  // Obtener usuarios desde localStorage
  usuarios = JSON.parse(localStorage.getItem("usuarios"));
  
  // Validar credenciales incluyendo el documento
  usuarioActivo = usuarios.find(
    (user) => user.documento === documento && user.usuario === username && user.contrasena === password
  );
  
  if (usuarioActivo) {
    mostrarDashboard();
  } else {
    mostrarMensaje("Datos incorrectos. Verifique su documento, usuario y contraseña.", "error");
  }
});

// Mostrar el dashboard con información del usuario
function mostrarDashboard() {
  document.querySelector(".container").style.display = "none";
  dashboard.style.display = "flex";
  navBar.classList.add("active");

  saldoPesos.textContent = usuarioActivo.saldo.toFixed(2);
  saldoDolares.textContent = usuarioActivo.saldoUSD.toFixed(2);
  cuentaAhorro.textContent = usuarioActivo.cuentas.ahorro;
  cuentaCorriente.textContent = usuarioActivo.cuentas.corriente;
  cuentaUSD.textContent = usuarioActivo.cuentas.usd;
  limiteVisa.textContent = usuarioActivo.tarjetas.visa.toFixed(2);
  limiteMastercard.textContent = usuarioActivo.tarjetas.mastercard.toFixed(2);
}

// Mostrar mensaje en el DOM
function mostrarMensaje(mensaje, tipo) {
  messageDiv.textContent = mensaje;
  messageDiv.style.color = tipo === "error" ? "red" : "green";
}

// Manejo del cierre de sesión
logoutButton.addEventListener("click", () => {
  dashboard.style.display = "none";
  document.querySelector(".container").style.display = "flex";
  navBar.classList.remove("active");
  documentoInput.value = "";
  usernameInput.value = "";
  passwordInput.value = "";
  mostrarMensaje("", "");
  usuarioActivo = null;
});

// Evento para abrir el modal de prestamos
document.getElementById("btn-prestamos").addEventListener("click", function () {
  document.getElementById("modal-prestamos").style.display = "block";
});

// Evento para cerrar el modal de prestamos
document.querySelector(".close").addEventListener("click", function () {
  document.getElementById("modal-prestamos").style.display = "none";
});

// Evento para calcular el prestamo
document.getElementById("calcular-prestamo").addEventListener("click", function () {
  const monto = parseFloat(document.getElementById("monto-prestamo").value);
  const cuotas = parseInt(document.getElementById("cuotas-prestamo").value);
  let interes = 0;

  // Determinar el porcentaje de interes segun la cantidad de cuotas
  switch (cuotas) {
    case 12:
      interes = 0.15;
      break;
    case 18:
      interes = 0.25;
      break;
    case 24:
      interes = 0.40;
      break;
    case 32:
      interes = 0.65;
      break;
    default:
      interes = 0;
  }

  // Calcular cuota mensual
  if (!isNaN(monto) && monto > 0) {
    const montoFinal = monto + monto * interes;
    const cuotaMensual = montoFinal / cuotas;
    document.getElementById("resultado-prestamo").textContent = `Total a pagar: $${montoFinal.toFixed(2)} | Cuotas de $${cuotaMensual.toFixed(2)}`;
  } else {
    document.getElementById("resultado-prestamo").textContent = "Ingrese un monto válido.";
  }
});

// Cerrar modal si se hace clic fuera de él
window.addEventListener("click", function (event) {
  const modal = document.getElementById("modal-prestamos");
  if (event.target === modal) {
    modal.style.display = "none";
  }
});
